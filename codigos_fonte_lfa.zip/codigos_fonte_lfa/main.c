#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "automato.h"
#include "file.h"

// fun��o principal
int main() {
    AUTOMATO * automato = ler_automato();
    char palavra[MAX]; // ser� lida no main, inserida pelo usu�rio

    if(automato != NULL){

        while (1) { // loop infinito
            printf("Digite uma palavra para testar (ou 'exit' para sair): ");
            scanf("%s", palavra); // l� a palavra do usu�rio

            if (strcmp(palavra, "exit") == 0) {
                printf("Programa encerrado!\n");
                break; // sai do loop se o usu�rio digitar 'exit'
            }

            // Chama a fun��o de simula��o
            simular(palavra, automato->alfabeto, automato->estados, automato->finais, automato->transicoes, automato->n_estados, automato->n_finais, automato->n_transicoes);

            printf("\n"); // Adiciona uma linha em branco para melhorar a legibilidade
        }
    }

    free(automato);
    return 0;
}

