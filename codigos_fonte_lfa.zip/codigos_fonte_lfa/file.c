#include <stdio.h>
#include <stdlib.h>
#include "file.h"
#include "automato.h"

//L� o arquivo txt com as informa��es do aut�mato
//Pr�-condi��o: nenhuma
//P�s-condi��o: nenhuma
AUTOMATO * ler_automato(){
    AUTOMATO * automato = malloc(sizeof(AUTOMATO));
    char nome_arquivo[MAX];

    printf("Digite o nome do arquivo com a especifica��o do AFD: ");
    scanf("%s", nome_arquivo); // l� o nome do arquivo
    FILE * arquivo = fopen(nome_arquivo, "r"); // abre o arquivo para leitura

    if (arquivo == NULL) { // se n�o conseguiu abrir o arquivo
        printf("ERRO: n�o foi poss�vel abrir o arquivo\n"); // imprime uma mensagem de erro
        return NULL;
    }

    ler_alfabeto(arquivo, automato->alfabeto); // l� o alfabeto do arquivo
    ler_estados(arquivo, automato->estados, &(automato->n_estados)); // l� os estados do arquivo
    ler_finais(arquivo, automato->finais, &(automato->n_finais)); // l� os estados finais do arquivo
    ler_transicoes(arquivo, automato->transicoes, &(automato->n_transicoes)); // l� as transi��es do arquivo
    fclose(arquivo); // fecha o arquivo
    printf("AFD carregado com sucesso\n"); // imprime uma mensagem de sucesso

    return automato;
}
