#include <stdio.h>
#include <string.h>
#include "automato.h"

// fun��o para ler o alfabeto de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es do alfabeto do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "alfabeto"
void ler_alfabeto(FILE *arquivo, char alfabeto[MAX]) {
    char linha[MAX];
    fgets(linha, MAX, arquivo); // l� a primeira linha
    sscanf(linha, "alfabeto={%[^}]}", alfabeto); // extrai o alfabeto entre chaves
}

// fun��o para ler os estados de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es dos estados do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "estados"
void ler_estados(FILE *arquivo, char estados[MAX][MAX], int *n) {
    char linha[MAX];
    char *token;
    fgets(linha, MAX, arquivo); // l� a segunda linha
    token = strtok(linha, "={,}"); // separa a linha por =, {, , e }
    token = strtok(NULL, "={,}"); // ignora o primeiro token (estados)
    *n = 0; // inicializa o contador de estados
    while (token != NULL) { // enquanto houver tokens
        strcpy(estados[*n], token); // copia o token para o vetor de estados
        (*n)++; // incrementa o contador de estados
        token = strtok(NULL, "={,}"); // obt�m o pr�ximo token
    }
}

// fun��o para ler os estados finais de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es dos estados finais do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "finais"
void ler_finais(FILE *arquivo, char finais[MAX][MAX], int *n) {
    char linha[MAX];
    char *token;
    fgets(linha, MAX, arquivo); // l� a terceira linha
    token = strtok(linha, "={,}"); // separa a linha por =, {, , e }
    token = strtok(NULL, "={,}"); // ignora o primeiro token (finais)
    *n = 0; // inicializa o contador de estados finais
    while (token != NULL) { // enquanto houver tokens
        strcpy(finais[*n], token); // copia o token para o vetor de estados finais
        (*n)++; // incrementa o contador de estados finais
        token = strtok(NULL, "={,}"); // obt�m o pr�ximo token
    }
}

// fun��o para ler as transi��es de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es das transi��es do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "transicoes"
void ler_transicoes(FILE *arquivo, TRANSICAO transicoes[MAX], int *n) {
    char linha[MAX];
    *n = 0; // inicializa o contador de transi��es
    while (fgets(linha, MAX, arquivo) != NULL) { // enquanto houver linhas no arquivo
        sscanf(linha, "(%[^,],%[^)])= %[^ \n]", transicoes[*n].estado_atual, transicoes[*n].simbolo, transicoes[*n].proximo_estado); // extrai os campos da transi��o
        (*n)++; // incrementa o contador de transi��es
    }
}

//fun��o para verificar se um estado � final
//Pr�-condi��o: nenhuma
//P�s-condi��o: deve retornar 1 caso o estado seja final e 0 caso n�o seja um estado final
int eh_final(char estado[MAX], char finais[MAX][MAX], int n) {
    for (int i = 0; i < n; i++) { // percorre o vetor de estados finais
        if (strcmp(estado, finais[i]) == 0) { // se o estado � igual a algum estado final
            return 1; // retorna verdadeiro
        }
    }
    return 0; // retorna falso
}

// fun��o para obter o pr�ximo estado a partir de um estado atual e um s�mbolo
//Pr�-condi��o: nenhuma
//P�s-condi��o: deve retornar NULL caso n�o houver pr�xima transi��o poss�vel
char *proximo_estado(char estado_atual[MAX], char simbolo[MAX], TRANSICAO transicoes[MAX], int n) {
    for (int i = 0; i < n; i++) { // percorre o vetor de transi��es
        if (strcmp(estado_atual, transicoes[i].estado_atual) == 0 && strcmp(simbolo, transicoes[i].simbolo) == 0) { // se a transi��o corresponde ao estado atual e ao s�mbolo
            return transicoes[i].proximo_estado; // retorna o pr�ximo estado
        }
    }
    return NULL; // retorna nulo se n�o houver transi��o
}

// fun��o para simular o AFD em uma palavra
//Pr�-condi��o: nenhuma
//P�s-condi��o: imprime na tela "ACEITA" caso o aut�mato aceite a palavra e "REJEITA" caso contr�rio
void simular(char palavra[MAX], char alfabeto[MAX], char estados[MAX][MAX], char finais[MAX][MAX], TRANSICAO transicoes[MAX], int n_estados, int n_finais, int n_transicoes) {
    char estado_atual[MAX];
    char simbolo[MAX];
    char *proximo;
    int i = 0;
    strcpy(estado_atual, estados[0]); // assume o primeiro estado como inicial
    printf("[%s]%s\n", estado_atual, palavra); // imprime o estado inicial e a palavra
    while (palavra[i] != '\0') { // enquanto n�o chegar ao final da palavra
        sprintf(simbolo, "%c", palavra[i]); // converte o caractere para string
        if (strchr(alfabeto, palavra[i]) == NULL) { // se o caractere n�o pertence ao alfabeto
            printf("REJEITA\n"); // imprime uma mensagem de erro
            return; // encerra a fun��o
        }
        proximo = proximo_estado(estado_atual, simbolo, transicoes, n_transicoes); // obt�m o pr�ximo estado
        if (proximo == NULL) { // se n�o houver pr�ximo estado
            printf("REJEITA\n"); // imprime uma mensagem de erro
            return; // encerra a fun��o
        }
        strcpy(estado_atual, proximo); // atualiza o estado atual
        i++; // avan�a para o pr�ximo caractere
        printf("[%s]%s\n", estado_atual, palavra + i); // imprime o estado atual e o restante da palavra
    }
    if (eh_final(estado_atual, finais, n_finais)) { // se o estado atual � final
        printf("ACEITA\n"); // imprime uma mensagem de aceita��o
    } else { // se o estado atual n�o � final
        printf("REJEITA\n"); // imprime uma mensagem de rejei��o
    }
}
