#ifndef FILE_H
#define FILE_H

#include "automato.h"

//L� o arquivo txt com as informa��es do aut�mato
//Pr�-condi��o: nenhuma
//P�s-condi��o: nenhuma
AUTOMATO * ler_automato();

#endif // FILE_H
