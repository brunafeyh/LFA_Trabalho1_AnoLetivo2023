#ifndef AUTOMATO_H
#define AUTOMATO_H

#define MAX 100 // tamanho m�ximo do alfabeto, estados e transi��es

// estrutura para representar uma transi��o
typedef struct {
    char estado_atual[MAX];
    char simbolo[MAX];
    char proximo_estado[MAX];
} TRANSICAO;

// estrutura para representar as propriedades de um aut�mato
typedef struct{
    char alfabeto[MAX], estados[MAX][MAX], finais[MAX][MAX];
    TRANSICAO transicoes[MAX];
    int n_estados, n_finais, n_transicoes;
} AUTOMATO;

// fun��o para ler o alfabeto de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es do alfabeto do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "alfabeto"
void ler_alfabeto(FILE *arquivo, char alfabeto[MAX]);

// fun��o para ler os estados de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es dos estados do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "estados"
void ler_estados(FILE *arquivo, char estados[MAX][MAX], int *n);

// fun��o para ler os estados finais de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es dos estados finais do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "finais"
void ler_finais(FILE *arquivo, char finais[MAX][MAX], int *n);

// fun��o para ler as transi��es de um arquivo
//Pr�-condi��o: arquivo deve estar aberto para leitura
//P�s-condi��o: as informa��es das transi��es do aut�mato s�o lidas do arquivo e armazenadas na vari�vel "transicoes"
void ler_transicoes(FILE *arquivo, TRANSICAO transicoes[MAX], int *n);

// fun��o para verificar se um estado � final
//Pr�-condi��o: nenhuma
//P�s-condi��o: deve retornar 1 caso o estado seja final e 0 caso n�o seja um estado final
int eh_final(char estado[MAX], char finais[MAX][MAX], int n);

// fun��o para obter o pr�ximo estado a partir de um estado atual e um s�mbolo
//Pr�-condi��o: nenhuma
//P�s-condi��o: deve retornar NULL caso n�o houver pr�xima transi��o poss�vel
char *proximo_estado(char estado_atual[MAX], char simbolo[MAX], TRANSICAO transicoes[MAX], int n);

// fun��o para simular o AFD em uma palavra
//Pr�-condi��o: nenhuma
//P�s-condi��o: imprime na tela "ACEITA" caso o aut�mato aceite a palavra e "REJEITA" caso contr�rio
void simular(char palavra[MAX], char alfabeto[MAX], char estados[MAX][MAX], char finais[MAX][MAX], TRANSICAO transicoes[MAX], int n_estados, int n_finais, int n_transicoes);

#endif // AUTOMATO_H
